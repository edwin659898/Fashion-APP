package com.example.fashionicon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends AppCompatActivity {
    private EditText editTextTextPersonName, editTextTextPersonName2, editTextTextPersonName4, editTextNumberPassword2;
    private Button button3;

    DatabaseHelper DH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        editTextTextPersonName =  findViewById(R.id.editTextTextPersonName);
        editTextTextPersonName2 =  findViewById(R.id.editTextTextPersonName2);
        editTextTextPersonName4 =  findViewById(R.id.editTextTextPersonName4);
        editTextNumberPassword2 = findViewById(R.id.editTextNumberPassword2);

        button3 = findViewById(R.id.button3);

        DH = new DatabaseHelper(this);

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = editTextTextPersonName4.getText().toString();
                String pass = editTextNumberPassword2.getText().toString();

                if (name.isEmpty() || pass.isEmpty()){
                    Toast.makeText(Registration.this, "Incomplete Credentials!", Toast.LENGTH_SHORT).show();
                }else{
                    Boolean checkUser = DH.checkUsername(name);
                    if(checkUser == false){
                        Boolean insert = DH.insertData(name, pass);
                        if(insert == true){
                            Toast.makeText(Registration.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent (getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                        }else
                            Toast.makeText(Registration.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                    }else
                        Toast.makeText(Registration.this, "User already exists!", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}