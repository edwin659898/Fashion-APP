package com.example.fashionicon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText editTextTextPersonName3, editTextNumberPassword;
    private Button button, button2;

    DatabaseHelper DH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTextPersonName3 = findViewById(R.id.editTextTextPersonName3);
        editTextNumberPassword = findViewById(R.id.editTextNumberPassword);

        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);

        DH = new DatabaseHelper(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = editTextTextPersonName3.getText().toString();
                String pas = editTextNumberPassword.getText().toString();

                if (user.isEmpty() || pas.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Incomplete Credentials!", Toast.LENGTH_SHORT).show();
                } else {
                    Boolean checkUser = DH.checkUsername(user);
                    if (checkUser == false) {
                        Toast.makeText(MainActivity.this, "Account does not exist. Registration required!", Toast.LENGTH_SHORT).show();
                    }else {
                        Boolean checkUserPass = DH.checkUsernamePassword(user, pas);
                        if (checkUserPass == false) {
                            Toast.makeText(MainActivity.this, "Incorrect Password!", Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(MainActivity.this, "Logged in!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), Menu.class);
                            startActivity(intent);
                        }
                    }
                }
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Registration.class);
                startActivity(intent);
            }
        });

    }
}